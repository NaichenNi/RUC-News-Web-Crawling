#!/usr/bin/python
#-*-coding:utf-8-*-

import scrapy
from scrapy.selector import Selector
from scrapy.http import Request
from scrapy import log
import re


from RucReport.items import RucReportItem

class RucReportSpider(scrapy.Spider):
    name='RucReport'
    allowed_domains=['ruc.edu.cn']
    
    start_urls=[
        'http://www.ruc.edu.cn/loadnoticelist?tid=3&lid=1'
        ]

    def parse(self,response):
        sel= scrapy.selector.Selector(response)
        site=sel.xpath('//div[@class="dcmc-notice"]')

# enter the link in Request, grab title and time
        if 'nid' in response.url:
            item= RucReportItem()
            title=site.xpath('div[@class="nc_title"]/text()').extract()
            time1=site.xpath('div[@class="nc_meta"]//span[@class="date"]/text()').extract()



# transform time1 into string "time_str" and use re group to get dates
            time_str=str(time1)
            time=re.search(r'(\d+)-(\d+)-(\d+)',time_str).group(0)
            
# form a dictionary
            item['title']=[n.encode('utf-8') for n in title]
            item['time']=[time] 
            yield item

# grab all links on the start url and put them into Request(first start)
        for url in sel.xpath('//ul[@class="noticelist"]/li/a/@href').extract():
            yield Request(url,callback=self.parse)


# grab all next page links and put them into Request
        for next_url in sel.xpath('//div[@class="content_col_2_nav"]/div[@class="content_col_2_nav_alignright"]/a/@href').extract():

            yield Request(next_url,callback=self.parse)

